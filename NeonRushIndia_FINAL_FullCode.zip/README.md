# Neon Rush India V4
Polished portrait endless-runner prototype built with Kotlin and a custom Canvas view.
Features: animated neon city, 3 lanes, swipe controls, jump, coins, obstacles, Shield/Magnet/Boost power-ups, pause, high score, missions and skin preview.
