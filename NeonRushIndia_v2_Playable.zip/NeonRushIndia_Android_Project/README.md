# Neon Rush India 🎮

A simple playable Android endless-runner prototype made for phone-first development.

### Controls
- Swipe left/right: change lane
- Swipe up: jump action (adds a small score boost in this prototype)
- Collect coin tokens
- Dodge red obstacles

### Build
Use the included GitHub Actions workflow. It builds a debug APK with Android SDK 36 and Java 17.
