package com.neonrushindia.game;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.content.*;
import android.media.AudioManager;
import android.media.ToneGenerator;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(new RushView(this));
    }
}

class RushView extends View {
    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Random r = new Random();
    final ToneGenerator tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 55);
    final android.content.SharedPreferences prefs;
    float touchX, touchY;
    int lane = 1;
    boolean playing = false, gameOver = false;
    long score = 0;
    int coins = 0, highScore = 0;
    float speed = 9f, spawn = 0, jump = 0, roadScroll = 0;
    long shieldUntil = 0, magnetUntil = 0, boostUntil = 0;
    ArrayList<Item> items = new ArrayList<>();
    long last;
    float[] laneX = new float[3];

    RushView(Context c) {
        super(c);
        p.setTypeface(Typeface.create("sans", Typeface.BOLD));
        prefs = c.getSharedPreferences("neonrush", Context.MODE_PRIVATE);
        highScore = prefs.getInt("high", 0);
        last = System.currentTimeMillis();
        setFocusable(true);
    }

    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        drawBackground(c, w, h);
        laneX[0] = w*.28f; laneX[1] = w*.50f; laneX[2] = w*.72f;
        drawRoad(c, w, h);
        if (!playing && !gameOver) { drawMenu(c,w,h); return; }
        if (playing) update(w,h);
        drawItems(c,w,h);
        drawPlayer(c,w,h);
        drawHud(c,w,h);
        if (gameOver) drawGameOver(c,w,h);
        postInvalidateOnAnimation();
    }

    void drawBackground(Canvas c,float w,float h) {
        for(int y=0;y<h;y+=10){
            int v=(int)(10+45*y/h);
            p.setColor(Color.rgb(4,7,v)); c.drawRect(0,y,w,y+10,p);
        }
        p.setColor(0x55202055);
        for(int i=0;i<8;i++){
            float x=i*w/7f;
            c.drawRect(x,h*.18f,x+w*.07f,h*.48f,p);
        }
        p.setColor(0x77FF2AAE);
        for(int i=0;i<7;i++) c.drawRect((i*190+roadScroll)%w,h*.28f,(i*190+roadScroll)%w+5,h*.55f,p);
    }

    void drawRoad(Canvas c,float w,float h) {
        Path q=new Path(); q.moveTo(w*.10f,0);q.lineTo(w*.90f,0);q.lineTo(w*.99f,h);q.lineTo(w*.01f,h);q.close();
        p.setColor(Color.rgb(18,21,43)); c.drawPath(q,p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4); p.setColor(Color.rgb(90,80,180));
        c.drawLine(w*.39f,0,w*.39f,h,p); c.drawLine(w*.61f,0,w*.61f,h,p); p.setStyle(Paint.Style.FILL);
        roadScroll += playing ? speed*.7f : .5f;
        p.setColor(0x55FFFFFF);
        for(int y=-80;y<h;y+=90){ float yy=(y+roadScroll)%90; c.drawRect(w*.445f,yy,w*.455f,yy+45,p); c.drawRect(w*.545f,yy,w*.555f,yy+45,p); }
    }

    void drawMenu(Canvas c,float w,float h) {
        p.setTextAlign(Paint.Align.CENTER);
        p.setColor(Color.WHITE); p.setTextSize(w*.115f); c.drawText("NEON RUSH",w/2,h*.25f,p);
        p.setColor(Color.rgb(255,179,0)); p.setTextSize(w*.07f); c.drawText("INDIA",w/2,h*.34f,p);
        p.setColor(Color.rgb(35,40,75)); c.drawRoundRect(w*.18f,h*.51f,w*.82f,h*.63f,30,30,p);
        p.setColor(Color.WHITE); p.setTextSize(w*.065f); c.drawText("▶  PLAY",w/2,h*.59f,p);
        p.setTextSize(w*.038f); p.setColor(Color.LTGRAY); c.drawText("Swipe ← →  Move   •   Swipe ↑  Jump",w/2,h*.70f,p);
        c.drawText("Collect coins • Power-ups • Dodge obstacles",w/2,h*.75f,p);
        p.setColor(Color.rgb(255,195,30)); p.setTextSize(w*.042f); c.drawText("BEST  "+highScore,w/2,h*.84f,p);
    }

    void startGame(){ playing=true; gameOver=false; score=0; coins=0; speed=9f; spawn=.4f; jump=0; shieldUntil=magnetUntil=boostUntil=0; items.clear(); lane=1; last=System.currentTimeMillis(); invalidate(); }

    void update(float w,float h) {
        long now=System.currentTimeMillis(); float dt=Math.min(.04f,(now-last)/1000f); last=now;
        score += (long)(dt*100);
        speed = Math.min(23f, 9f + score/700f);
        if(now < boostUntil) speed = Math.min(28f, speed+7f);
        roadScroll += speed*dt*30;
        if(jump>0) jump=Math.max(0,jump-dt);

        spawn -= dt;
        if(spawn<=0){
            spawn=Math.max(.40f,1.0f-score/17000f);
            int l=r.nextInt(3);
            float roll=r.nextFloat();
            int type = roll<.48f ? 0 : (roll<.77f ? 1 : (roll<.84f ? 2 : (roll<.90f ? 3 : (roll<.95f ? 4 : 5))));
            items.add(new Item(l,-80,type));
            if(r.nextFloat()<.22f) items.add(new Item(r.nextInt(3),-230,0));
        }

        for(int i=items.size()-1;i>=0;i--){
            Item it=items.get(i); it.y += speed*60*dt;
            if(it.y>h+120){items.remove(i);continue;}
            float targetX=laneX[lane]; float dx=Math.abs(targetX-laneX[it.lane]);
            if(it.type==0 && now<magnetUntil && it.y>h*.45f && it.y<h*.82f && dx<w*.28f) dx=0;
            if(it.y>h*.72f && it.y<h*.88f && dx<w*.12f){
                if(it.type==0){coins++; score+=250; beep(1); items.remove(i);}
                else if(it.type==1){
                    if(now<shieldUntil){ shieldUntil=0; beep(2); items.remove(i); }
                    else { endGame(); return; }
                } else if(it.type==2){shieldUntil=now+6500;score+=100;beep(3);items.remove(i);}
                else if(it.type==3){magnetUntil=now+7000;score+=100;beep(3);items.remove(i);}
                else if(it.type==4){boostUntil=now+5000;score+=100;beep(3);items.remove(i);}
                else if(it.type==5){ if(jump<=0.05f && now>=shieldUntil){ endGame(); return; } else {score+=150;items.remove(i);} }
            }
        }
    }

    void endGame(){
        playing=false; gameOver=true;
        if(score>highScore){highScore=(int)score;prefs.edit().putInt("high",highScore).apply();}
        beep(0);
    }
    void beep(int kind){ try{ tone.startTone(kind==0?ToneGenerator.TONE_PROP_NACK:ToneGenerator.TONE_PROP_BEEP, kind==0?180:70); }catch(Exception ignored){} }

    void drawItems(Canvas c,float w,float h){
        long now=System.currentTimeMillis();
        for(Item it:items){ float x=laneX[it.lane], y=it.y;
            if(it.type==0){ p.setColor(Color.rgb(255,190,20));c.drawCircle(x,y,20,p);p.setColor(Color.WHITE);p.setTextSize(18);p.setTextAlign(Paint.Align.CENTER);c.drawText("₹",x,y+6,p); }
            else if(it.type==1){ p.setColor(Color.rgb(235,45,75));c.drawRoundRect(x-31,y-25,x+31,y+25,12,12,p);p.setColor(Color.WHITE);c.drawRect(x-11,y-7,x+11,y+7,p); }
            else { int col = it.type==2?Color.CYAN:(it.type==3?Color.rgb(170,90,255):it.type==4?Color.rgb(60,255,130):Color.rgb(255,100,100)); p.setColor(col);c.drawCircle(x,y,25,p);p.setColor(Color.WHITE);p.setTextSize(13);p.setTextAlign(Paint.Align.CENTER);c.drawText(it.type==2?"SHIELD":it.type==3?"MAGNET":it.type==4?"BOOST":"JUMP",x,y+5,p); }
        }
        if(now<shieldUntil){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(6);p.setColor(Color.CYAN);c.drawCircle(laneX[lane],h*.82f,58,p);p.setStyle(Paint.Style.FILL);}
    }

    void drawPlayer(Canvas c,float w,float h){
        float x=laneX[lane], y=h*.82f - (jump>0 ? (float)Math.sin((jump/0.55f)*Math.PI)*h*.20f : 0);
        p.setColor(Color.rgb(255,70,160)); c.drawRoundRect(x-28,y-50,x+28,y+40,18,18,p);
        p.setColor(Color.rgb(255,205,155)); c.drawCircle(x,y-62,22,p);
        p.setColor(Color.rgb(25,25,45));c.drawCircle(x,y-70,22,p);
        p.setColor(Color.rgb(255,190,0));c.drawRect(x-32,y+38,x-8,y+58,p);c.drawRect(x+8,y+38,x+32,y+58,p);
        p.setColor(Color.WHITE);p.setTextSize(13);p.setTextAlign(Paint.Align.CENTER);c.drawText("NR",x,y-58,p);
    }

    void drawHud(Canvas c,float w,float h){
        p.setTextAlign(Paint.Align.LEFT);p.setTextSize(20);p.setColor(Color.WHITE);c.drawText("SCORE  "+score,22,36,p);
        p.setTextAlign(Paint.Align.RIGHT);p.setColor(Color.rgb(255,195,30));c.drawText("COINS  "+coins,w-22,36,p);
        long now=System.currentTimeMillis(); p.setTextAlign(Paint.Align.CENTER);p.setTextSize(14);
        if(now<shieldUntil)c.drawText("SHIELD",w*.28f,64,p);
        if(now<magnetUntil)c.drawText("MAGNET",w*.50f,64,p);
        if(now<boostUntil)c.drawText("BOOST",w*.72f,64,p);
    }

    void drawGameOver(Canvas c,float w,float h){
        p.setColor(0xDD05060D);c.drawRect(0,0,w,h,p);p.setTextAlign(Paint.Align.CENTER);
        p.setColor(Color.WHITE);p.setTextSize(w*.10f);c.drawText("GAME OVER",w/2,h*.34f,p);
        p.setColor(Color.rgb(255,179,0));p.setTextSize(w*.055f);c.drawText("Score: "+score,w/2,h*.43f,p);c.drawText("Coins: "+coins,w/2,h*.49f,p);
        p.setColor(Color.CYAN);p.setTextSize(w*.045f);c.drawText("Best: "+highScore,w/2,h*.55f,p);
        p.setColor(Color.rgb(35,40,75));c.drawRoundRect(w*.20f,h*.64f,w*.80f,h*.75f,28,28,p);p.setColor(Color.WHITE);p.setTextSize(w*.05f);c.drawText("TAP TO RUN AGAIN",w/2,h*.71f,p);
    }

    public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()==MotionEvent.ACTION_DOWN){ touchX=e.getX();touchY=e.getY(); return true; }
        if(e.getAction()==MotionEvent.ACTION_UP){
            float dx=e.getX()-touchX, dy=e.getY()-touchY;
            if(!playing){ startGame(); return true; }
            if(Math.abs(dx)>Math.abs(dy) && Math.abs(dx)>45) lane=Math.max(0,Math.min(2,lane+(dx>0?1:-1)));
            else if(dy<-55 && jump<=0.05f) { jump=.55f; score+=50; beep(2); }
            invalidate(); return true;
        }
        return true;
    }

    static class Item { int lane,type; float y; Item(int l,float yy,int t){lane=l;y=yy;type=t;} }
}
