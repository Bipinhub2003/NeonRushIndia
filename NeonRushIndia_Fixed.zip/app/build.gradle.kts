plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.neonrush.india"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.neonrush.india"
        minSdk = 24
        targetSdk = 36
        versionCode = 3
        versionName = "1.0.3"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
