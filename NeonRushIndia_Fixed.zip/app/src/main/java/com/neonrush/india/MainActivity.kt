package com.neonrush.india

import android.app.Activity
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.graphics.*
import kotlin.math.abs
import kotlin.math.max
import kotlin.random.Random

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        setContentView(GameView())
    }

    inner class GameView : View(this) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }
        private var running = false
        private var gameOver = false
        private var lane = 1
        private var jump = 0f
        private var score = 0
        private var coins = 0
        private var speed = 10f
        private var last = 0L
        private var spawn = 0f
        private val obstacles = mutableListOf<Pair<Int, Float>>()
        private val coinList = mutableListOf<Pair<Int, Float>>()
        private var downX = 0f
        private var downY = 0f

        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val w = width.toFloat(); val h = height.toFloat()
            c.drawColor(Color.rgb(5,5,16))
            drawRoad(c,w,h)
            if (!running && !gameOver) drawMenu(c,w,h)
            else {
                update(h)
                drawObjects(c,w,h)
                drawPlayer(c,w,h)
                drawHud(c,w,h)
                if (gameOver) drawGameOver(c,w,h)
                postInvalidateDelayed(16)
            }
        }

        private fun drawRoad(c:Canvas,w:Float,h:Float) {
            p.color = Color.rgb(12,12,30); c.drawRect(w*.12f,0f,w*.88f,h,p)
            p.color = Color.rgb(25,25,55)
            c.drawRect(w*.395f,0f,w*.405f,h,p); c.drawRect(w*.595f,0f,w*.605f,h,p)
            p.color = Color.rgb(30,30,65)
            var y = 0f
            while(y<h){ c.drawRect(w*.49f,y,w*.51f,y+35,p); y+=70 }
        }

        private fun drawMenu(c:Canvas,w:Float,h:Float) {
            text.textSize=w*.11f; text.color=Color.CYAN; text.textAlign=Paint.Align.CENTER
            c.drawText("NEON RUSH",w/2,h*.23f,text)
            text.textSize=w*.065f; text.color=Color.WHITE
            c.drawText("INDIA",w/2,h*.31f,text)
            p.color=Color.rgb(20,120,180); c.drawRoundRect(w*.25f,h*.55f,w*.75f,h*.65f,30f,30f,p)
            text.textSize=w*.055f; text.color=Color.WHITE; c.drawText("PLAY",w/2,h*.615f,text)
            text.textSize=w*.035f; text.color=Color.LTGRAY
            c.drawText("Swipe ← → to move   •   Swipe ↑ to jump",w/2,h*.72f,text)
        }

        private fun update(h:Float) {
            if(!running || gameOver) return
            val now=System.currentTimeMillis()
            if(last==0L) last=now
            val dt=(now-last)/16f; last=now
            score += max(1,(speed/8).toInt())
            speed = minOf(24f, speed + .003f*dt)
            spawn += dt
            if(spawn>38f) {
                spawn=0f
                val l=Random.nextInt(3)
                if(Random.nextBoolean()) obstacles.add(l to -80f) else coinList.add(l to -80f)
            }
            obstacles.replaceAll { it.first to it.second + speed*dt }
            coinList.replaceAll { it.first to it.second + speed*dt }
            obstacles.removeAll { it.second>h+100 }
            coinList.removeAll { it.second>h+100 }
            if(jump>0f) jump=max(0f,jump-dt*.045f)
            val playerY=h*.78f
            val hitY=h*.78f
            val hit=obstacles.firstOrNull { it.first==lane && abs(it.second-hitY)<55f && jump<.25f }
            if(hit!=null) { gameOver=true; running=false }
            val got=coinList.firstOrNull { it.first==lane && abs(it.second-hitY)<60f }
            if(got!=null){ coins++; coinList.remove(got) }
        }

        private fun drawObjects(c:Canvas,w:Float,h:Float){
            obstacles.forEach { (l,y)-> 
                val x=w*(.27f+.23f*l); p.color=Color.rgb(255,70,80)
                c.drawRoundRect(x-32,y-22,x+32,y+22,12f,12f,p)
            }
            coinList.forEach { (l,y)->
                val x=w*(.27f+.23f*l); p.color=Color.YELLOW; c.drawCircle(x,y,18f,p)
            }
        }

        private fun drawPlayer(c:Canvas,w:Float,h:Float){
            val x=w*(.27f+.23f*lane); val y=h*.78f-jump*h*.18f
            p.color=Color.rgb(0,220,255); c.drawRoundRect(x-28,y-55,x+28,y+5,18f,18f,p)
            p.color=Color.WHITE; c.drawCircle(x-10,y-34,5f,p); c.drawCircle(x+10,y-34,5f,p)
            p.color=Color.rgb(20,20,40); c.drawCircle(x-10,y-34,2f,p); c.drawCircle(x+10,y-34,2f,p)
        }

        private fun drawHud(c:Canvas,w:Float,h:Float){
            text.textAlign=Paint.Align.LEFT; text.textSize=w*.042f; text.color=Color.WHITE
            c.drawText("SCORE  $score",25f,45f,text)
            text.textAlign=Paint.Align.RIGHT; c.drawText("🪙 $coins",w-25f,45f,text)
        }

        private fun drawGameOver(c:Canvas,w:Float,h:Float){
            p.color=Color.argb(190,0,0,0); c.drawRect(0f,0f,w,h,p)
            text.textAlign=Paint.Align.CENTER; text.textSize=w*.085f; text.color=Color.RED
            c.drawText("GAME OVER",w/2,h*.38f,text)
            text.textSize=w*.05f; text.color=Color.WHITE
            c.drawText("Score: $score",w/2,h*.46f,text)
            p.color=Color.rgb(20,120,180); c.drawRoundRect(w*.25f,h*.55f,w*.75f,h*.65f,30f,30f,p)
            text.textSize=w*.05f; c.drawText("RESTART",w/2,h*.615f,text)
        }

        override fun onTouchEvent(e:MotionEvent):Boolean{
            if(e.action==MotionEvent.ACTION_DOWN){downX=e.x;downY=e.y;return true}
            if(e.action==MotionEvent.ACTION_UP){
                val dx=e.x-downX; val dy=e.y-downY
                if(!running && !gameOver){ running=true; last=0L; invalidate(); return true }
                if(gameOver){ gameOver=false; score=0;coins=0;speed=10f;lane=1;jump=0f;obstacles.clear();coinList.clear();running=true;last=0L;invalidate();return true}
                if(abs(dx)>abs(dy) && abs(dx)>50) lane=(lane + if(dx>0) 1 else -1).coerceIn(0,2)
                else if(dy < -50 && jump<=0f) jump=1f
                invalidate(); return true
            }
            return true
        }
    }
}
