# Neon Rush India
Simple offline endless runner Android game prototype.
Controls: swipe left/right to change lanes, swipe up to jump.
