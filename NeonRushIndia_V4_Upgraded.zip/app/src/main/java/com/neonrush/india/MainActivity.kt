package com.neonrush.india

import android.app.Activity
import android.content.Context
import android.graphics.*
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        setContentView(GameView(this))
    }

    class GameView(ctx: Context) : View(ctx) {
        private val prefs = ctx.getSharedPreferences("neon_rush", Context.MODE_PRIVATE)
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
        private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }

        private enum class Screen { MENU, GAME, GAME_OVER, SKINS, MISSIONS }
        private enum class Power { SHIELD, MAGNET, BOOST }
        private data class Obj(var lane: Int, var y: Float, var type: Int, var rot: Float = 0f)

        private var screen = Screen.MENU
        private var paused = false
        private var lane = 1
        private var playerY = 0f
        private var jump = 0f
        private var score = 0
        private var coins = 0
        private var best = prefs.getInt("best", 0)
        private var totalCoins = prefs.getInt("coins", 0)
        private var speed = 8f
        private var distance = 0f
        private var roadScroll = 0f
        private var spawnTimer = 0f
        private var powerTimer = 0f
        private var last = 0L
        private var selectedSkin = prefs.getInt("skin", 0)
        private var activePower: Power? = null
        private var powerLeft = 0f
        private var shake = 0f
        private var downX = 0f
        private var downY = 0f

        private val obstacles = mutableListOf<Obj>()
        private val coinsList = mutableListOf<Obj>()
        private val powers = mutableListOf<Obj>()
        private val buildings = ArrayList<Float>()

        init {
            isFocusable = true
            for (i in 0 until 18) buildings.add(Random.nextFloat())
        }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            drawBackground(c, w, h)

            when (screen) {
                Screen.MENU -> drawMenu(c, w, h)
                Screen.GAME -> {
                    if (!paused) update(h)
                    drawGame(c, w, h)
                    if (paused) drawPause(c, w, h)
                    postInvalidateDelayed(16)
                }
                Screen.GAME_OVER -> {
                    drawGame(c, w, h)
                    drawGameOver(c, w, h)
                }
                Screen.SKINS -> drawSkins(c, w, h)
                Screen.MISSIONS -> drawMissions(c, w, h)
            }
        }

        private fun drawBackground(c: Canvas, w: Float, h: Float) {
            val sky = LinearGradient(0f, 0f, 0f, h, Color.rgb(8, 8, 28), Color.rgb(25, 8, 48), Shader.TileMode.CLAMP)
            p.shader = sky
            c.drawRect(0f, 0f, w, h, p)
            p.shader = null

            // moon and skyline
            p.color = Color.rgb(130, 110, 255)
            c.drawCircle(w * .78f, h * .13f, w * .06f, p)

            var x = 0f
            for (i in buildings.indices) {
                val bw = w * (.055f + buildings[i] * .06f)
                val bh = h * (.16f + buildings[(i + 5) % buildings.size] * .23f)
                p.color = if (i % 2 == 0) Color.rgb(12, 12, 38) else Color.rgb(18, 10, 43)
                c.drawRect(x, h * .52f - bh, x + bw, h * .52f, p)
                p.color = Color.rgb(85, 40, 150)
                for (yy in h * .52f - bh + 22f; yy < h * .52f - 10f; yy += 28f) {
                    if ((i + yy.toInt()) % 3 != 0) c.drawRect(x + 8f, yy, x + bw - 8f, yy + 5f, p)
                }
                x += bw + 5f
                if (x > w) break
            }
        }

        private fun roadBounds(w: Float): Pair<Float, Float> = Pair(w * .14f, w * .86f)

        private fun drawRoad(c: Canvas, w: Float, h: Float) {
            val (left, right) = roadBounds(w)
            p.color = Color.rgb(12, 12, 28)
            c.drawRect(left, 0f, right, h, p)

            // neon road edges
            glow.color = Color.rgb(0, 220, 255)
            glow.strokeWidth = 8f
            glow.style = Paint.Style.STROKE
            c.drawLine(left, 0f, left, h, glow)
            c.drawLine(right, 0f, right, h, glow)
            glow.style = Paint.Style.FILL

            // lane dividers scrolling
            p.color = Color.rgb(52, 35, 85)
            val lane1 = left + (right-left)/3f
            val lane2 = left + 2f*(right-left)/3f
            var y = -80f + roadScroll
            while (y < h) {
                c.drawRoundRect(lane1-5f, y, lane1+5f, y+42f, 5f, 5f, p)
                c.drawRoundRect(lane2-5f, y, lane2+5f, y+42f, 5f, 5f, p)
                y += 78f
            }

            // subtle perspective center lights
            p.color = Color.rgb(28, 24, 58)
            var yy = -40f + roadScroll * .5f
            while (yy < h) {
                c.drawRect(w*.49f, yy, w*.51f, yy+18f, p)
                yy += 56f
            }
        }

        private fun laneX(w: Float, l: Int): Float {
            val (left, right) = roadBounds(w)
            return left + (right-left) * (l + .5f) / 3f
        }

        private fun drawMenu(c: Canvas, w: Float, h: Float) {
            // title
            t.textAlign = Paint.Align.CENTER
            t.textSize = w * .12f
            t.color = Color.CYAN
            c.drawText("NEON RUSH", w/2f, h*.20f, t)
            t.textSize = w * .06f
            t.color = Color.WHITE
            c.drawText("INDIA", w/2f, h*.27f, t)
            t.textSize = w * .033f
            t.color = Color.rgb(180, 160, 220)
            c.drawText("RUN • DODGE • COLLECT • SURVIVE", w/2f, h*.32f, t)

            drawPlayerPreview(c, w/2f, h*.43f, 1.0f)

            button(c, w*.20f, h*.55f, w*.80f, h*.64f, "PLAY NOW", true)
            button(c, w*.20f, h*.67f, w*.48f, h*.74f, "SKINS", false)
            button(c, w*.52f, h*.67f, w*.80f, h*.74f, "MISSIONS", false)

            t.textSize = w*.032f
            t.color = Color.LTGRAY
            c.drawText("BEST  $best    •    COINS  $totalCoins", w/2f, h*.82f, t)
            t.textSize = w*.028f
            c.drawText("Swipe ← → to change lane   •   Swipe ↑ to jump", w/2f, h*.89f, t)
        }

        private fun button(c: Canvas, l: Float, top: Float, r: Float, b: Float, label: String, primary: Boolean) {
            p.color = if (primary) Color.rgb(0, 150, 210) else Color.rgb(33, 25, 64)
            c.drawRoundRect(l, top, r, b, 24f, 24f, p)
            glow.color = if (primary) Color.CYAN else Color.rgb(130, 80, 220)
            glow.style = Paint.Style.STROKE
            glow.strokeWidth = 3f
            c.drawRoundRect(l, top, r, b, 24f, 24f, glow)
            glow.style = Paint.Style.FILL
            t.textAlign = Paint.Align.CENTER
            t.textSize = (b-top)*.40f
            t.color = Color.WHITE
            c.drawText(label, (l+r)/2f, top+(b-top)*.64f, t)
        }

        private fun startGame() {
            screen = Screen.GAME
            paused = false
            lane = 1
            jump = 0f
            score = 0
            coins = 0
            speed = 8f
            distance = 0f
            roadScroll = 0f
            spawnTimer = 0f
            powerTimer = 0f
            activePower = null
            powerLeft = 0f
            obstacles.clear()
            coinsList.clear()
            powers.clear()
            last = 0L
            invalidate()
        }

        private fun update(h: Float) {
            val now = System.currentTimeMillis()
            if (last == 0L) last = now
            val dt = ((now-last)/16f).coerceIn(.5f, 2.5f)
            last = now

            distance += speed * dt
            score += max(1, (speed/8f).toInt())
            speed = min(19f, speed + .0025f*dt)
            roadScroll = (roadScroll + speed*dt) % 78f

            spawnTimer += dt
            powerTimer += dt
            if (spawnTimer > max(23f, 48f - speed*1.4f)) {
                spawnTimer = 0f
                val l = Random.nextInt(3)
                val roll = Random.nextInt(100)
                if (roll < 58) obstacles.add(Obj(l, -80f, 0))
                else if (roll < 86) coinsList.add(Obj(l, -60f, 0))
                else coinsList.add(Obj(l, -60f, 0, Random.nextFloat()*6.28f))
                if (Random.nextInt(100) < 28) {
                    val other = (l + Random.nextInt(1,3)) % 3
                    obstacles.add(Obj(other, -150f, 0))
                }
            }
            if (powerTimer > 170f) {
                powerTimer = 0f
                val l = Random.nextInt(3)
                powers.add(Obj(l, -90f, Random.nextInt(3)))
            }

            obstacles.forEach { it.y += speed*dt }
            coinsList.forEach { it.y += speed*dt }
            powers.forEach { it.y += speed*dt }

            obstacles.removeAll { it.y > h+100f }
            coinsList.removeAll { it.y > h+100f }
            powers.removeAll { it.y > h+100f }

            if (jump > 0f) jump = max(0f, jump - .055f*dt)
            if (activePower != null) {
                powerLeft -= dt
                if (powerLeft <= 0f) activePower = null
            }

            val py = h*.78f - jump*h*.20f
            val hit = obstacles.firstOrNull { it.lane == lane && abs(it.y - h*.78f) < 58f && jump < .24f }
            if (hit != null) {
                if (activePower == Power.SHIELD) {
                    activePower = null
                    powerLeft = 0f
                    obstacles.remove(hit)
                    shake = 12f
                } else {
                    endGame()
                    return
                }
            }

            val magnet = activePower == Power.MAGNET
            val coin = coinsList.firstOrNull {
                val laneNear = it.lane == lane || (magnet && abs(it.lane-lane) <= 1)
                laneNear && abs(it.y - py) < (if (magnet) 130f else 58f)
            }
            if (coin != null) {
                coins++
                totalCoins++
                coinsList.remove(coin)
                if (coins > 0 && coins % 10 == 0) score += 100
            }

            val power = powers.firstOrNull { it.lane == lane && abs(it.y-py) < 65f }
            if (power != null) {
                activePower = Power.values()[power.type]
                powerLeft = 240f
                powers.remove(power)
                score += 50
            }
            if (shake > 0f) shake -= dt
        }

        private fun endGame() {
            if (score > best) {
                best = score
                prefs.edit().putInt("best", best).putInt("coins", totalCoins).apply()
            } else prefs.edit().putInt("coins", totalCoins).apply()
            screen = Screen.GAME_OVER
            paused = false
        }

        private fun drawGame(c: Canvas, w: Float, h: Float) {
            c.save()
            if (shake > 0f) c.translate(Random.nextFloat()*shake-shake/2f, Random.nextFloat()*shake-shake/2f)
            drawRoad(c, w, h)

            obstacles.forEach { drawCar(c, laneX(w,it.lane), it.y, w*.07f) }
            coinsList.forEach { drawCoin(c, laneX(w,it.lane), it.y, w*.025f) }
            powers.forEach { drawPower(c, laneX(w,it.lane), it.y, w*.035f, Power.values()[it.type]) }

            val py = h*.78f - jump*h*.20f
            drawPlayer(c, laneX(w,lane), py, w*.085f, jump > 0f)

            c.restore()
            drawHud(c,w,h)
        }

        private fun drawCar(c: Canvas, x: Float, y: Float, s: Float) {
            p.color = Color.rgb(255, 55, 90)
            c.drawRoundRect(x-s, y-s*.55f, x+s, y+s*.55f, s*.35f, s*.35f, p)
            p.color = Color.rgb(35, 35, 58)
            c.drawRoundRect(x-s*.55f, y-s*.40f, x+s*.55f, y+s*.05f, s*.20f, s*.20f, p)
            p.color = Color.WHITE
            c.drawCircle(x-s*.58f, y+s*.36f, s*.16f, p)
            c.drawCircle(x+s*.58f, y+s*.36f, s*.16f, p)
            p.color = Color.rgb(255, 220, 80)
            c.drawCircle(x-s*.72f, y-s*.12f, s*.10f, p)
            c.drawCircle(x+s*.72f, y-s*.12f, s*.10f, p)
        }

        private fun drawCoin(c: Canvas, x: Float, y: Float, r: Float) {
            p.color = Color.rgb(255, 205, 35)
            c.drawCircle(x,y,r*1.25f,p)
            p.color = Color.rgb(255, 245, 120)
            c.drawCircle(x,y,r*.92f,p)
            t.textAlign = Paint.Align.CENTER
            t.textSize = r*1.05f
            t.color = Color.rgb(130, 80, 0)
            c.drawText("₹",x,y+r*.36f,t)
        }

        private fun drawPower(c: Canvas, x: Float, y: Float, r: Float, power: Power) {
            val col = when(power) {
                Power.SHIELD -> Color.rgb(0, 210, 255)
                Power.MAGNET -> Color.rgb(210, 80, 255)
                Power.BOOST -> Color.rgb(255, 150, 20)
            }
            p.color = col
            c.drawCircle(x,y,r*1.5f,p)
            t.textAlign = Paint.Align.CENTER
            t.textSize = r*.95f
            t.color = Color.WHITE
            c.drawText(when(power){Power.SHIELD->"S";Power.MAGNET->"M";Power.BOOST->"B"},x,y+r*.34f,t)
        }

        private fun drawPlayer(c: Canvas, x: Float, y: Float, s: Float, airborne: Boolean) {
            val body = when(selectedSkin) {
                1 -> Color.rgb(255, 90, 120)
                2 -> Color.rgb(160, 100, 255)
                else -> Color.rgb(0, 220, 255)
            }
            // glow
            glow.color = body
            glow.setShadowLayer(18f,0f,0f,body)
            c.drawCircle(x,y-s*.35f,s*.48f,glow)
            glow.clearShadowLayer()

            p.color = body
            c.drawRoundRect(x-s*.45f,y-s*.9f,x+s*.45f,y+s*.15f,s*.25f,s*.25f,p)
            p.color = Color.rgb(245,245,255)
            c.drawCircle(x-s*.16f,y-s*.56f,s*.09f,p)
            c.drawCircle(x+s*.16f,y-s*.56f,s*.09f,p)
            p.color = Color.rgb(20,20,45)
            c.drawCircle(x-s*.16f,y-s*.56f,s*.045f,p)
            c.drawCircle(x+s*.16f,y-s*.56f,s*.045f,p)
            p.color = Color.rgb(35,35,65)
            val leg = if (airborne) s*.18f else 0f
            c.drawRoundRect(x-s*.34f,y+s*.08f,x-s*.10f,y+s*.50f+leg,s*.10f,s*.10f,p)
            c.drawRoundRect(x+s*.10f,y+s*.08f,x+s*.34f,y+s*.50f-leg,s*.10f,s*.10f,p)
        }

        private fun drawPlayerPreview(c: Canvas, x: Float, y: Float, scale: Float) {
            drawPlayer(c, x, y, width*.12f*scale, false)
        }

        private fun drawHud(c: Canvas, w: Float, h: Float) {
            // top glass cards
            p.color = Color.argb(190, 14, 10, 35)
            c.drawRoundRect(18f,18f,w*.43f,72f,22f,22f,p)
            c.drawRoundRect(w*.57f,18f,w-18f,72f,22f,22f,p)

            t.textAlign = Paint.Align.LEFT
            t.textSize = w*.038f
            t.color = Color.WHITE
            c.drawText("SCORE  $score",34f,53f,t)
            t.textAlign = Paint.Align.RIGHT
            c.drawText("COINS  $coins",w-34f,53f,t)

            // pause
            p.color = Color.rgb(45,35,75)
            c.drawRoundRect(w*.43f,88f,w*.57f,136f,18f,18f,p)
            t.textAlign = Paint.Align.CENTER
            t.textSize = 22f
            t.color = Color.WHITE
            c.drawText("Ⅱ",w*.50f,120f,t)

            if (activePower != null) {
                val pct = (powerLeft/240f).coerceIn(0f,1f)
                p.color = Color.argb(180, 20, 18, 48)
                c.drawRoundRect(w*.22f,h*.10f,w*.78f,h*.145f,18f,18f,p)
                p.color = when(activePower){Power.SHIELD->Color.CYAN;Power.MAGNET->Color.MAGENTA;Power.BOOST->Color.rgb(255,160,30)}
                c.drawRoundRect(w*.22f,h*.10f,w*.22f+w*.56f*pct,h*.145f,18f,18f,p)
                t.textSize = w*.027f
                t.color = Color.WHITE
                c.drawText(when(activePower){Power.SHIELD->"SHIELD";Power.MAGNET->"MAGNET";Power.BOOST->"BOOST"},w*.50f,h*.132f,t)
            }
        }

        private fun drawPause(c: Canvas, w: Float, h: Float) {
            p.color = Color.argb(205, 3, 3, 12)
            c.drawRect(0f,0f,w,h,p)
            t.textAlign = Paint.Align.CENTER
            t.textSize = w*.09f
            t.color = Color.WHITE
            c.drawText("PAUSED",w/2f,h*.40f,t)
            button(c,w*.25f,h*.50f,w*.75f,h*.60f,"RESUME",true)
            button(c,w*.25f,h*.63f,w*.75f,h*.73f,"MENU",false)
        }

        private fun drawGameOver(c: Canvas, w: Float, h: Float) {
            p.color = Color.argb(220, 3, 3, 12)
            c.drawRect(0f,0f,w,h,p)
            t.textAlign = Paint.Align.CENTER
            t.textSize = w*.085f
            t.color = Color.rgb(255, 75, 100)
            c.drawText("RUN OVER",w/2f,h*.31f,t)
            t.textSize = w*.045f
            t.color = Color.WHITE
            c.drawText("SCORE  $score",w/2f,h*.40f,t)
            c.drawText("BEST   $best",w/2f,h*.46f,t)
            c.drawText("COINS  $coins",w/2f,h*.52f,t)
            button(c,w*.20f,h*.60f,w*.80f,h*.69f,"RUN AGAIN",true)
            button(c,w*.20f,h*.72f,w*.80f,h*.80f,"MAIN MENU",false)
        }

        private fun drawSkins(c: Canvas, w: Float, h: Float) {
            t.textAlign = Paint.Align.CENTER
            t.textSize = w*.08f
            t.color = Color.WHITE
            c.drawText("SKINS",w/2f,h*.14f,t)
            val names = arrayOf("CYAN RUNNER","PINK FLASH","PURPLE PRO")
            val ys = floatArrayOf(.30f,.52f,.74f)
            for (i in 0..2) {
                p.color = if (selectedSkin == i) Color.rgb(35,75,100) else Color.rgb(25,20,48)
                c.drawRoundRect(w*.16f,h*ys[i]-.08f*h,w*.84f,h*ys[i]+.08f*h,24f,24f,p)
                drawPlayer(c,w*.29f,h*ys[i],w*.07f,false)
                t.textAlign = Paint.Align.LEFT
                t.textSize = w*.038f
                t.color = Color.WHITE
                c.drawText(names[i],w*.42f,h*ys[i]-.01f*h,t)
                t.textSize = w*.026f
                t.color = if (selectedSkin == i) Color.CYAN else Color.LTGRAY
                c.drawText(selectedSkin==i ? "EQUIPPED" : "TAP TO EQUIP",w*.42f,h*ys[i]+.045f*h,t)
            }
            button(c,w*.22f,h*.87f,w*.78f,h*.94f,"BACK",false)
        }

        private fun drawMissions(c: Canvas, w: Float, h: Float) {
            t.textAlign = Paint.Align.CENTER
            t.textSize = w*.08f
            t.color = Color.WHITE
            c.drawText("MISSIONS",w/2f,h*.14f,t)
            mission(c,w,h,.28f,"FIRST RUN","Complete one run",score >= 1)
            mission(c,w,h,.46f,"COIN HUNTER","Collect 10 coins",totalCoins >= 10)
            mission(c,w,h,.64f,"HIGH FLYER","Jump over obstacles",best >= 500)
            mission(c,w,h,.82f,"ROAD LEGEND","Reach 1000 score",best >= 1000)
            button(c,w*.22f,h*.90f,w*.78f,h*.97f,"BACK",false)
        }

        private fun mission(c:Canvas,w:Float,h:Float,y:Float,title:String,sub:String,done:Boolean) {
            p.color = if(done) Color.rgb(24,70,65) else Color.rgb(25,20,48)
            c.drawRoundRect(w*.12f,h*y-.055f*h,w*.88f,h*y+.055f*h,20f,20f,p)
            t.textAlign = Paint.Align.LEFT
            t.textSize = w*.035f
            t.color = Color.WHITE
            c.drawText(title,w*.20f,h*y-.005f*h,t)
            t.textSize = w*.025f
            t.color = if(done) Color.CYAN else Color.LTGRAY
            c.drawText(if(done) "COMPLETED" else sub,w*.20f,h*y+.035f*h,t)
            t.textAlign = Paint.Align.RIGHT
            t.textSize = w*.05f
            t.color = if(done) Color.CYAN else Color.GRAY
            c.drawText(if(done) "✓" else "•",w*.80f,h*y+.015f*h,t)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (e.action == MotionEvent.ACTION_DOWN) {
                downX = e.x
                downY = e.y
                return true
            }
            if (e.action != MotionEvent.ACTION_UP) return true

            val dx = e.x-downX
            val dy = e.y-downY
            val w = width.toFloat()
            val h = height.toFloat()

            when (screen) {
                Screen.MENU -> {
                    if (e.y > h*.52f && e.y < h*.66f) startGame()
                    else if (e.y > h*.66f && e.y < h*.77f && e.x < w*.50f) screen = Screen.SKINS
                    else if (e.y > h*.66f && e.y < h*.77f && e.x >= w*.50f) screen = Screen.MISSIONS
                }
                Screen.GAME -> {
                    if (paused) {
                        if (e.y > h*.48f && e.y < h*.63f) paused = false
                        else if (e.y > h*.62f && e.y < h*.76f) screen = Screen.MENU
                    } else {
                        // pause button
                        if (e.y < 155f && e.x > w*.40f && e.x < w*.60f) {
                            paused = true
                        } else if (abs(dx) > abs(dy) && abs(dx) > 45f) {
                            lane = (lane + if (dx > 0) 1 else -1).coerceIn(0,2)
                        } else if (dy < -45f && jump <= 0f) {
                            jump = 1f
                        }
                    }
                }
                Screen.GAME_OVER -> {
                    if (e.y > h*.57f && e.y < h*.71f) startGame()
                    else if (e.y > h*.71f && e.y < h*.84f) screen = Screen.MENU
                }
                Screen.SKINS -> {
                    if (e.y > h*.20f && e.y < h*.38f) selectedSkin = 0
                    else if (e.y >= h*.38f && e.y < h*.61f) selectedSkin = 1
                    else if (e.y >= h*.61f && e.y < h*.86f) selectedSkin = 2
                    else if (e.y > h*.85f) screen = Screen.MENU
                    prefs.edit().putInt("skin", selectedSkin).apply()
                }
                Screen.MISSIONS -> {
                    if (e.y > h*.86f) screen = Screen.MENU
                }
            }
            invalidate()
            return true
        }
    }
}
